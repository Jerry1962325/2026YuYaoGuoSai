#!/bin/bash
# 一键启动 way_point.py 录制模式
# 用法：
#   tools/script/waypoint_record.sh                # 默认保存到 tools/waypoints.json
#   tools/script/waypoint_record.sh path/to/file.json # 保存到指定 JSON 文件

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "${PROJECT_ROOT}" || exit 1

WAYPOINT_FILE="${1:-tools/waypoints.json}"

exec python3 tools/way_point.py record "${WAYPOINT_FILE}"
