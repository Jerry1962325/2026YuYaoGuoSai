#!/bin/bash
# 一键启动 way_point.py 回放模式（broadcast 模式），并在后台启动 pose_controller_node.py
# 用法：
#   tools/script/waypoint_playback.sh                # 默认加载 tools/waypoints.json
#   tools/script/waypoint_playback.sh path/to/file.json # 加载指定 JSON 文件

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
cd "${PROJECT_ROOT}" || exit 1

WAYPOINT_FILE="${1:-tools/waypoints.json}"
POSE_CONTROLLER="lite3_ws/src/pose_control/pose_controller_node.py"

# 在后台启动 pose_controller_node.py
python3 "${POSE_CONTROLLER}" &
POSE_PID=$!
echo "pose_controller_node.py 已在后台启动，PID: ${POSE_PID}"

# 当前终端启动 way_point.py 回放
exec python3 tools/way_point.py broadcast "${WAYPOINT_FILE}"
